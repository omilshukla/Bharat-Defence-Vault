
import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>🇮🇳 Bharat Defence Vault</h1>
      <p>Explore Indian Armed Forces structure and military assets.</p>
      <ul>
        <li>✈️ Fighter Jets</li>
        <li>🚢 Naval Assets</li>
        <li>🚛 Ground Vehicles</li>
        <li>🛡️ Armed Forces Structure</li>
        <li>🪙 NFT Minting (Testnet)</li>
      </ul>
    </div>
  );
}

export default App;
